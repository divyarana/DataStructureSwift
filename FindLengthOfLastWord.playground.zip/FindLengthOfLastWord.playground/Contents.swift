import Cocoa
/* Find the length of the last word
Input =  “Hello world”
Output = 5
 
Input = “  world ”
Output = 5
 
Input = “”
Output = 0 */

func findLengthOfLastWord(_ valueStr: String) -> Int {
    var count = 0
    var isWhiteSpaceEncountered = false
    for (index, value) in valueStr.enumerated() {
        //If character is not a whitespace
        if value != " " {
            if isWhiteSpaceEncountered {
                count = 0
                isWhiteSpaceEncountered = false
            }
            count += 1
        } else {
            if value == " " && index < (valueStr.count - 1) {
                isWhiteSpaceEncountered = true
                continue
            }
            if index == (valueStr.count - 1) {
                return count
            } else {
                count = 0
            }
       }
    }
     return count
}

print(findLengthOfLastWord(" I am finding the length of the last word "))


